import React, { Component } from 'react';

const weatherurl = 'https://newsapi.org/v2/top-headlines?country=us&apiKey=bbaa5b3d1a634fe38beca404c864ff89';

class Weather extends Component {

    state = {
        weather: undefined,
        temp: undefined,
        wind: undefined,
        humid: undefined,
        visibility: undefined,
        error: undefined
    }

    getWeather= async () => {
         const api_call = await fetch(weatherurl);
         const data = await api_call.json();
         console.log(data);
         try{this.setState({
            weather: data.weather[0].description,
            temp: data.main.temp,
            wind: data.wind.speed,
            humid: data.main.humidity,
            visibility: data.visibility,
            error:""
         });
        }
        catch(e){alert("Error")}
    }

    

    render() {
        // setInterval(this.getWeather, 5000);
        this.getWeather();
        return (
            <div className="thridPartyApi">
                <div className="APIcontent">{this.state.temp}</div>
                <div className="APIcontent">{this.state.weather}</div>
                <div className="APIcontent">{this.state.visibility}</div>
                <div className="APIcontent">{this.state.wind}</div>
                <div className="APIcontent">{this.state.humid}</div>
                <div className="APIcontent">{this.state.error}</div>
            </div>

        );
    }  
}

export default Weather;
