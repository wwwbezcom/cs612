import React, { Component } from 'react';

class Header extends Component {
  render() {
    return (
      <div className="overallheader">
        <h1>Assignment 4</h1>
      </div>
    );
  }  
}

export default Header;
