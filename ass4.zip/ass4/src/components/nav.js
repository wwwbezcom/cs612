import React, { Component } from 'react';
import Homepagelink from './Navigation/homepagelink'
import Weather from './Navigation/weather';

class Nav extends Component {
  render() {
    return (

       <div className="nav">

            <Homepagelink />

            <Weather />

        </div>

    );
  }  
}

export default Nav;
