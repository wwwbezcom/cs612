import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
        <div className="footer">
            <p>@Enze Bai U01695401 CS612</p>
        </div>
    );
  }  
}

export default Footer;
